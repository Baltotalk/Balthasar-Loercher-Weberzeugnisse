import javax.swing.*;
import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.border.Border;
import java.awt.BorderLayout;
import java.awt.*;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.SQLOutput;
import java.util.Scanner;
import java.util.Timer;

public class Main {

        public static void bosj10() throws InterruptedException {
            System.out.println("Herzlich Willkommen im neuen B.OS J!");
            Thread.sleep(1000);
            System.out.println("Leider ist B.OS J noch in der Entwicklung. Zurzeit wird allerdings verstärkt am neuen B.OS 3.0 gearbeitet.\nWenn Sie nicht auf B.OS 3.0 umsteigen wollen, können sie ruhig bei B.OS 2.0 bleiben, es wird bis zum 31. Dezember 2022 unterstützt.\nWenn Sie dauerhaft bei B.OS in Javaausführung bleiben wollen, haben Sie etwas Geduld bis B.OS J bereit ist.\nBitte beachten Sie allerdings, dass die B.OS 3 Serie (B.OS 3.0*, B.OS 3.1**, B.OS Lite 2022/04, B.OS Lite 2022/07*) deutliche Vorteile gegenüber der B.OS 2 Serie (B.OS 2.0, B.OS J) und der B.OS Serie (B-DOS, B.OS 1.0, B.OS 1.2) bietet\n*in Entwicklung\n**in Planung ");
            Thread.sleep(3000);
            System.out.println("Sie werden nun in die B.OS 2.0 Shell zurückgeleitet");

        }

        public static void news() {
            System.out.println("----------\nNews\n----------");
            System.out.println("Herzlich Willkommen im B.OS 2.0 Benachrichtigungssystem!\n\nMELDUNGEN:\n\n");
            System.out.println("Sie verwenden eine alte B.OS Version! Ihr System wird bis zum 31.12.2022 unterstützt, überlegen Sie auf ein neueres B.OS zu updaten.\nDa Sie die B.OS 2.0 PE besitzen empfehlen wir Ihnen nicht, die kostenlose B.OS Lite Versionen zu verwenden. Wir empfehlen Ihnen ein für Sie kostenloses Upgrade auf B.OS 3.0 Pro.");
        }


        public static void main(String[] args) throws InterruptedException {

            long starttime = System.currentTimeMillis();
            String vers = "2.0.0";
            boolean operating = true;

            long uptime;

            long sysuptime;
            String eingabeauff = "\nWarte auf Eingabe. Befehlsliste mit -list. Sie sind angemeldet als" ;
            String befehlsliste = "\nBefehlsliste B.OS " + vers + ":\n\n-list = Befehlsliste \n-bosj = startet B.OS J 1.0\n-news = zeigt Benachrichtigungen an\n-insindat = gespeicherten Text in .txt-Datei speichern \n-destr = ACHTUNG! Nur für Entwickler! Dies ist der Entwicklermodus \n-exit = Herunterfahren \n-settings = Einstellungen \n-sysinfo = Systeminformationen \n-progs = integrierte Programme \n-wthr = workthrough \n-save = Öffnet eine Texteingabe und speichert den Text \n-ins = Gibt gespeicherten Text wieder \n-del = Löscht Text\n-dbos = Öffnet das D-B.OS \n-stats = Statistiken und Nutzerinformationen";
            //String hilfeanfrage = "\nHilfe: \n\nWobei benötigen sie Hilfe?";
            String error1 = "Fehlerhafte Eingabe";
            String systeminfo = "Systeminformationen \n\nBaltic Operating System Version " + vers + "\n\nCopyrighted 2022 and distributed by B.Lörcher \nWorkthrough Version 1.0.0\nSie besitzen die endültige Vollversion von Baltic Operating System 2.0 Professionell\nWir empfehlen Ihnen ein Upgrade auf das intuitive, neue B.OS 3.0 Multimedia- und Arbeitssystem.\nSie wollen bei Java bleiben? kein Problem! Es wird kein B.OS 3.0 in Java geben, allerdings wird es für Javafans ein stetig erweitertes B.OS 2.1 geben, B.OS J 1.0.";
            String einst = "Systemeinstellungen \n\nFolgende Befehle können sie ausführen um Einstellungen zu ändern:\n\n-language = Spracheinstellungen \n-bosversset = B.OS Versionseinstellungen ";
            String textwert = "Kein Text angegeben";
            String name = "User";
            String bestatigungb;
            String gebdat = "2000";
            String bestatigunggebb;
            boolean namensabfrage = true;
            boolean datumsabfrage = true;
            System.out.println("Baltic Operating System Version " + vers + " wird gestartet...");
            Thread.sleep(5000);
            System.out.println("Sie haben es gleich geschafft!");
            Thread.sleep(3000);
            System.out.println("Achtung! wir konnten feststellen, dass Ihre B.OS Version nicht mehr die aktuellste ist. B.OS 2.0 wird bis zum 31.12.2022 unterstützt, überlegen Sie, auf B.OS 3.0 zu updaten.");
            Thread.sleep(1000);
            System.out.println("Mehr Informationen mit -news in der Hauptshell. Der Startvorgang wird fortgesetzt, Herzlich Willkommen!");
            Thread.sleep(1000);
            System.out.println("---------------------------------------\nBALTIC OPERATING SYSTEM 2.0\nProfessionell Edition\n---------------------------------------");
            Thread.sleep(3000);
            System.out.println("Geben Sie jetzt bitte Ihren VORNAMEN an und drücken Sie ENTER:");




            while(namensabfrage==true) {
                Scanner namenseingabe = new Scanner(System.in);
                name = namenseingabe.nextLine();
                System.out.println("Okay. Ist dies korrekt? " + name + " (J/N)");
                Scanner bestatigung = new Scanner(System.in);
                bestatigungb = bestatigung.nextLine();
                if (bestatigungb.equals("J")) {
                    System.out.println("Okay, Ihr Name wurde auf " + name + " gesetzt.");
                    namensabfrage = false;

                } else  {
                    if (bestatigungb.equals("N")) {
                        System.out.println("Okay, bitte geben Sie ihren Namen erneut ein und drücken Sie ENTER:");
                        name = "User";
                    }
                    else{
                        System.out.println("Bitte geben Sie nur J oder N ein und drücken Sie ENTER. Geben Sie zur Sicherheit jetzt bitte nochmals Ihren Vornamen an.");
                    }


                }
            }
            System.out.println("Nun benötigen wir noch Ihr Geburtsjahr. Bitte geben Sie z.B. 2000 ein und drücken sie ENTER:");

            while(datumsabfrage == true) {

                Scanner datumseingabe = new Scanner(System.in);
                gebdat = datumseingabe.nextLine();
                System.out.println("Okay. Ist dies korrekt? " + gebdat + " (J/N)");
                Scanner bestatigunggeb = new Scanner(System.in);
                bestatigunggebb = bestatigunggeb.nextLine();
                if(bestatigunggebb.equals("J")) {
                    System.out.println("Okay, Ihr Geburtsjahr wurde gesetzt. Sie sind nun fertig und B.OS ist einsatzbereit.");
                    datumsabfrage = false;

                }
                else{
                    if(bestatigunggebb.equals("N")) {
                        System.out.println("Okay. Bitte geben Sie Ihr Geburtsjahr erneut ein und drücken sie ENTER:");
                    }
                    else{
                        System.out.println("Dies war eine fehlerhafte Eingabe. Bitte geben Sie NUR J oder N ein. Geben Sie jetzt Ihr Geburtsdatum erneut ein und drücken Sie ENTER:");
                    }
                }



            }

            System.out.println(eingabeauff + " " + name + "," + " geboren " + gebdat + ".");


            while (operating == true) {
                Scanner eingabe1 = new Scanner(System.in);
                String eingabes1 = eingabe1.nextLine();


                if (eingabes1.equals("-list")) {
                    System.out.println(befehlsliste);

                } else {
                    if (eingabes1.equals("-settings")) {
                        System.out.println(einst);

                    }
                    else {
                        if (eingabes1.equals("-sysinfo")) {
                            System.out.println(systeminfo);
                        }
                        else {
                            if (eingabes1.equals("-exit")) {
                                System.out.println("B.OS fährt herunter...");
                                System.exit(0);
                            }
                            else {
                                if (eingabes1.equals("-save")) {
                                    System.out.println("Bitte Text eingeben und ENTER drücken");
                                    Scanner texteingabe1 = new Scanner(System.in);
                                    textwert = texteingabe1.nextLine();
                                    System.out.println("Text wurde gespeichert.");

                                }
                                else {
                                    if (eingabes1.equals("-ins")) {
                                        System.out.println("Ihr gespeicherter Text:\n\n" + textwert );
                                    }
                                    else {
                                        if (eingabes1.equals("-del")) {
                                            textwert = null;
                                            System.out.println("Text wurde gelöscht");
                                        }
                                        else {
                                            if (eingabes1.equals("-progs")) {
                                                System.out.println("Derzeit integrierte Programme: \n\nWorkthrough mit -wthr");
                                            }
                                            else {
                                                if (eingabes1.equals("-wthr")) {
                                                    JFrame workthroughf = new JFrame("Workthrough");
                                                    workthroughf.setSize(900, 500);
                                                    workthroughf.setResizable(false);

                                                    JPanel panelwt1 = new JPanel();
                                                    JLabel neugikeitenwt1 = new JLabel("Mein Feed:");
                                                    panelwt1.add(neugikeitenwt1);

                                                    //Es folgt die Menübar
                                                    JMenuBar menubarwt1 = new JMenuBar();
                                                    //Es folgt das Menü
                                                    JMenu menuwt1 = new JMenu("Menü");
                                                    JMenu menuwt2 = new JMenu("Mein Workspace");
                                                    //Menüpunkte erzeugen
                                                    JMenuItem optionen = new JMenuItem("Optionen");
                                                    JMenuItem schliessen = new JMenuItem("Schließen");
                                                    JMenuItem auswahl = new JMenuItem("Auswahl");
                                                    JMenuItem anpassung = new JMenuItem("Anpassung");
                                                    JMenuItem infos = new JMenuItem("Infos");
                                                    //Hinzufügen der Punkte zum Menü
                                                    menuwt1.add(optionen);
                                                    menuwt1.add(schliessen);
                                                    menuwt1.add(auswahl);
                                                    menuwt2.add(anpassung);
                                                    menuwt2.add(infos);
                                                    //Untermenü wird zur Leiste hinzugefügt
                                                    menubarwt1.add(menuwt1);
                                                    menubarwt1.add(menuwt2);
                                                    //Menüleiste wird zum Fenster zugefügt
                                                    workthroughf.add(menubarwt1, BorderLayout.NORTH);


                                                    JTextField wtText1 = new JTextField("Herzlich Willkommen bei Workthrough 1.0.0 in ihrem B.OS System!", 15);
                                                    wtText1.setForeground(Color.DARK_GRAY);
                                                    wtText1.setEditable(false);

                                                    workthroughf.add(panelwt1);


                                                    workthroughf.setVisible(true);
                                                    workthroughf.toFront();
                                                }
                                                else {
                                                    if (eingabes1.equals("-destr")) {
                                                        System.out.println("WARNUNG, dieses System ist nun im Entwicklermodus, es kann unter Umständen ein Neustart erforderlich sein");
                                                        operating = false;
                                                    }
                                                    else {
                                                        if(eingabes1.equals("-dbos")) {
                                                            JFrame guibos = new JFrame("B.OS");
                                                            guibos.setSize(1280, 720);
                                                            guibos.setExtendedState(guibos.MAXIMIZED_BOTH);
                                                            guibos.setResizable(false);

                                                            JPanel panelbos1 = new JPanel();
                                                            JLabel labelbos1 = new JLabel("Mein Feed:");
                                                            panelbos1.add(labelbos1);

                                                            //Es folgt die Menübar
                                                            JMenuBar menubarbos = new JMenuBar();
                                                            //Es folgt das Menü
                                                            JMenu menubos = new JMenu("Startmenü");
                                                            //Menüpunkte erzeugen
                                                            JMenuItem start1 = new JMenuItem("Einstellungen");
                                                            //Hinzufügen der Punkte zum Menü
                                                            menubos.add(start1);
                                                            //Untermenü wird zur Leiste hinzugefügt
                                                            menubarbos.add(menubos);
                                                            //Menüleiste wird zum Fenster zugefügt
                                                            guibos.add(menubarbos, BorderLayout.SOUTH);

                                                            guibos.setVisible(true);
                                                        }
                                                        else {
                                                            if (eingabes1.equals("-linusisthebest")) {
                                                                System.out.println("Das ist wahr... misterls.de");
                                                            }
                                                            else {
                                                                if (eingabes1.equals("-insindat")) {
                                                                    System.out.println("Text wird als \"Textwert.txt\" im Verzeichnis von B.OS gespeichert.");
                                                                    try{
                                                                        Files.write(Paths.get("Textspeicher.txt"), textwert.getBytes());
                                                                    } catch (IOException e) {
                                                                        e.printStackTrace();
                                                                    }

                                                                }
                                                                else {
                                                                    if(eingabes1.equals("-stats")) {
                                                                        uptime = System.currentTimeMillis();
                                                                        sysuptime = (uptime / 1000 - starttime / 1000);
                                                                        System.out.println("System- und Nutzerstatistiken \n\nGuten Tag. Ihr Vorname ist " + name + "." + "\nSie sind geboren im Jahr " + gebdat + "." + "\nIhre Systemuptime: " + sysuptime + " Sekunden." + "\nIhre Baltic Operating System Professionell Edition Version: " + vers);
                                                                    }
                                                                    else if (eingabes1.equals("-bosj"))
                                                                    {
                                                                        bosj10();
                                                                    }
                                                                    else if (eingabes1.equals ("-news")){
                                                                        news();
                                                                    }

                                                                    else {
                                                                        System.out.println(error1);
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }


                                                }
                                            }

                                        }

                                    }

                                }


                            }

                        }

                    }
                }
                if(operating == true) {
                    System.out.println(eingabeauff + " " + name + "," + " geboren " + gebdat + ".");
                }
            }
            System.out.println("\n\nWillkommen im Entwicklermodus");
            System.out.println("\n\nWas ist der Entwicklermodus? \nSie sind nun außerhalb der Systemschleife und haben so nur auf einige wenige Befehle Zugriff.");
            System.out.println("\n\nWie komme ich wieder ins Hauptsystem?\nDies ist nun leider nicht mehr möglich. Zum Abschalten -exit.\n");

            while(operating == false) {
                System.out.println("\nGeben sie einen Befehl ein. Liste mit -devlist.");
                Scanner eingabe2 = new Scanner(System.in);
                String eingabes2 = eingabe2.nextLine();

                if (eingabes2.equals("-freeme")) {
                    System.out.println("Sie sind nun in der freien Eingabe");
                    operating = true;

                }
                else {
                    if (eingabes2.equals("-wthr")) {
                        System.out.println("Workthrough kann im Entwicklermodus leider nicht ausgeführt werden.");
                    }
                    else {
                        if (eingabes2.equals("-exit")) {
                            System.out.println("Das System wird nun heruntergefahren.");
                            System.exit(0);
                        }
                        else {
                            if(eingabes2.equals("-devlist")) {
                                System.out.println("Entwicklermodus Befehlsoptionen:\n\n-freeme = Freier Modus ACHTUNG! Neustart kann erforderlich sein!\n-exit = Herunterfahren\n-ins = Eingegebenen Text wiedergeben\n");
                            }
                            else {
                                if (eingabes2.equals("-ins")) {
                                    System.out.println("Ihr im B.OS gespeicherter Text: \n" + textwert);
                                }
                            }
                        }

                    }




                }
            }







        }
    }


