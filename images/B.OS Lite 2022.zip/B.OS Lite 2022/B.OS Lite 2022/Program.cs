﻿using System;
using System.Threading;

namespace ProjectSixtyNine
{
    class Program
    {
        public static void Main(String[] args)
        {

            Console.WriteLine("Herzlich Willkommen im B.OS Lite 2022, alles wird eingerichtet.");
            Thread.Sleep(2000);
            Console.WriteLine("Alles wurde eingericchtet. Sie können das System nun verwenden");
            bool operating = true;
            string inputValue = "Fehler. Kein Wert.";

            while (operating == true)
            {
                Console.WriteLine("Wartet auf Eingabe. Liste mit -list");

                string userInput = Console.ReadLine();

                if (userInput == "-list")
                {
                    Console.WriteLine("In der Liteversion sind die Befehle sehr eingeschränkt.\nBefehlsliste:\n\n-list = Liste\n-exit = Beendet Programm\n-save = Speichert Wert\n-ins = gibt Wert aus\n-del = Löscht Wert");
                }
                else if (userInput == "-exit")
                {
                    operating = false;
                    Console.WriteLine("System wird beendet. Holen Sie sich das neue B.OS 3.0 mit mehr als 50 Befehlen und neuen Funktionen!");
                    Environment.Exit(0);
                }
                else if(userInput == "-save")
                {
                    Console.WriteLine("Geben Sie den Wert ein.");
                    inputValue = Console.ReadLine();
                    Console.WriteLine("Wert gespeichert");
                }
                else if(userInput == "-ins")
                {
                    Console.WriteLine(inputValue);
                }
                else if(userInput == "-del")
                {
                    Console.WriteLine("Gelöscht");
                    inputValue = "Fehler. Kein Wert.";
                }
                else
                {
                    Console.WriteLine("Geben Sie einen gültigen Befehl ein.");
                }
            }













        }
    }
}

        



        